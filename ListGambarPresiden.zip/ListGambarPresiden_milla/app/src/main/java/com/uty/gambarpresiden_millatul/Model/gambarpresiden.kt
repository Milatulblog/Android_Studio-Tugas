package com.uty.gambarpresiden_millatul.Model

class gambarpresiden {
    var name: String = ""
    var detail: String = ""
    var poster: Int = 0
}