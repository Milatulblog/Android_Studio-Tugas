package com.uty.gambarpresiden_millatul.Model

import com.uty.gambarpresiden_millatul.R

object data_gambarpresiden {
    private val nama_gambarpresiden = arrayOf(
        "Presiden Soekarno",
        "Presiden Soeharto",
        "Presiden BJ Habieie",
        "Presiden Abdurahman Wahid",
        "Presiden Megawati Soekarno Putri",
        "Presiden Susuilo Bambang Yudhoyono",
        "Presiden Joko Widodo"

    )

    private val detail = arrayOf(
        "Presiden Soekarno adalah Presiden RI Ke - 1",
        "Presiden Soeharto adalah Presiden RI Ke - 2",
        "Presiden BJ Habiebie adalah Presiden RI Ke - 3",
        "Presiden Abdurahman Wahid adalah Presiden RI Ke - 4",
        "Presiden Megawati Soekarno Putri adalah Presiden RI Ke - 5",
        "Presiden Susilo Bambang Yudhoyono adalah Presiden RI Ke - 6",
        "Presiden Joko Widodo adalah Presiden RI Ke - 7"


    )

    private val gambarpresidenPoster = intArrayOf(
        R.drawable.soekarno,
        R.drawable.soeharto,
        R.drawable.habibie,
        R.drawable.gusdur,
        R.drawable.megawati,
        R.drawable.sby,
        R.drawable.jokowi


    )

    val list_gambarpresiden: ArrayList<com.uty.gambarpresiden_millatul.Model.gambarpresiden>
        get(){
            val list = arrayListOf<com.uty.gambarpresiden_millatul.Model.gambarpresiden>()
            for (position in nama_gambarpresiden.indices){
                val gambarpresiden = com.uty.gambarpresiden_millatul.Model.gambarpresiden()
                gambarpresiden.name = nama_gambarpresiden[position]
                gambarpresiden.detail = detail[position]
                gambarpresiden.poster = gambarpresidenPoster[position]
                list.add(gambarpresiden)
            }
            return list
        }
}