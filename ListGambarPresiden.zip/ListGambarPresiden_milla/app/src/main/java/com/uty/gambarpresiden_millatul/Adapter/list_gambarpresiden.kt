package com.uty.gambarpresiden_millatul.Adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.uty.gambarpresiden_millatul.R
import com.uty.gambarpresiden_millatul.Model.gambarpresiden
import com.uty.gambarpresiden_millatul.Model.data_gambarpresiden.list_gambarpresiden

class list_gambarpresiden (private val context: Context, private val gambarpresiden: ArrayList<gambarpresiden>, private val listener: (gambarpresiden) -> Unit)
    : RecyclerView.Adapter<list_gambarpresiden.ViewHolder>(){


    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ViewHolder {
        return ViewHolder(LayoutInflater.from(context).inflate(R.layout.list_gambarpresiden, parent, false))

    }

    override fun getItemCount(): Int {
        return list_gambarpresiden.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindgambarpresiden(gambarpresiden[position], listener)

    }

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var tvName: TextView = view.findViewById(R.id.tv_item_name)
        var tvDetail: TextView = view.findViewById(R.id.tv_item_detail)
        var imgPoster: ImageView = view.findViewById(R.id.img_item_poster)

        fun bindgambarpresiden(gambarpresiden: gambarpresiden, listener: (gambarpresiden) -> Unit){
            tvName.text = gambarpresiden.name
            tvDetail.text = gambarpresiden.detail
            Glide.with(itemView.context)
                .load(gambarpresiden.poster)
                .into(imgPoster)

            
        }
    }
}