package com.uty.gambarpresiden_millatul

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.uty.gambarpresiden_millatul.Adapter.list_gambarpresiden
import com.uty.gambarpresiden_millatul.Model.gambarpresiden
import com.uty.gambarpresiden_millatul.Model.data_gambarpresiden

class MainActivity : AppCompatActivity() {
    private lateinit var  rvgambarpresiden: RecyclerView
    private var list: ArrayList<gambarpresiden> = arrayListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rvgambarpresiden = findViewById(R.id.rv_gambarpresiden)
        rvgambarpresiden.setHasFixedSize(true)
        list.addAll(data_gambarpresiden.list_gambarpresiden)
        showgambarpresidenList()
    }

    private fun showgambarpresidenList(){
        rvgambarpresiden.layoutManager = LinearLayoutManager(this)
        rvgambarpresiden.adapter = list_gambarpresiden(this,list){
            Toast.makeText(this,it.detail,Toast.LENGTH_SHORT).show();
        }
    }
}
