package com.uty.Listviewicon_millatul.Adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.uty.Listviewicon_millatul.R
import com.uty.Listviewicon_millatul.Models.bahasapemrograman
import com.uty.Listviewicon_millatul.Models.data_bahasapemrograman.list_bahasapemrograman

class list_bahasapemrograman (private val context: Context, private val bahasapemrograman: ArrayList<bahasapemrograman>, private val listener: (bahasapemrograman) -> Unit)
    : RecyclerView.Adapter<list_bahasapemrograman.ViewHolder>(){


    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): list_bahasapemrograman.ViewHolder {
        return ViewHolder(LayoutInflater.from(context).inflate(R.layout.item_bahasapemrograman, parent, false))

    }

    override fun getItemCount(): Int {
        return list_bahasapemrograman.size
    }

    override fun onBindViewHolder(holder: list_bahasapemrograman.ViewHolder, position: Int) {
        holder.bindbahasapemrograman(bahasapemrograman[position], listener)

    }

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var tvName: TextView = view.findViewById(R.id.tv_item_name)
        var tvDetail: TextView = view.findViewById(R.id.tv_item_detail)
        var imgPoster: ImageView = view.findViewById(R.id.img_item_poster)

        fun bindbahasapemrograman(bahasapemrograman: bahasapemrograman, listener: (bahasapemrograman) -> Unit){
            tvName.text = bahasapemrograman.name
            tvDetail.text = bahasapemrograman.detail
            Glide.with(itemView.context)
                .load(bahasapemrograman.poster)
                .into(imgPoster)

            
        }
    }
}