package com.uty.Listviewicon_millatul.Models

import com.uty.Listviewicon_millatul.R

object data_bahasapemrograman {
    private val nama_bahasapemrograman = arrayOf(
        "Ruby",
        "Ralis",
        "Phyton",
        "Java Script",
        "PHP"
    )

    private val detail = arrayOf(
        "Ruby is an open-source and fully object-oriented programming language",
        "Ruby on Ralis is a server-side web application development framework written in Ruby language",
        "Phyton is interpreted scripting and object-oriented programming language",
        "Java Script is an object-based scripting language",
        "PHP is an interpreted language, i.e., there is no need for compilation"
    )

    private val bahasapemrogramanPoster = intArrayOf(
        R.drawable.ruby,
        R.drawable.ralis,
        R.drawable.phyton,
        R.drawable.javascript,
        R.drawable.php
    )

    val list_bahasapemrograman: ArrayList<com.uty.Listviewicon_millatul.Models.bahasapemrograman>
        get(){
            val list = arrayListOf<com.uty.Listviewicon_millatul.Models.bahasapemrograman>()
            for (position in nama_bahasapemrograman.indices){
                val bahasapemrograman = com.uty.Listviewicon_millatul.Models.bahasapemrograman()
                bahasapemrograman.name = nama_bahasapemrograman[position]
                bahasapemrograman.detail = detail[position]
                bahasapemrograman.poster = bahasapemrogramanPoster[position]
                list.add(bahasapemrograman)
            }
            return list
        }
}