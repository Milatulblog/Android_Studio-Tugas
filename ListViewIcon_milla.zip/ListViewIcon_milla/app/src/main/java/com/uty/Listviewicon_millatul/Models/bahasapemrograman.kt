package com.uty.Listviewicon_millatul.Models

class bahasapemrograman {
    var name: String = ""
    var detail: String = ""
    var poster: Int = 0
}