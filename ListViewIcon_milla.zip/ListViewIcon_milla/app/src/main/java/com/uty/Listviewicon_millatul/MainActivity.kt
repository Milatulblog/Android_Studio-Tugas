package com.uty.Listviewicon_millatul

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.uty.Listviewicon_millatul.Adapter.list_bahasapemrograman
import com.uty.Listviewicon_millatul.Models.bahasapemrograman
import com.uty.Listviewicon_millatul.Models.data_bahasapemrograman

class MainActivity : AppCompatActivity() {
    private lateinit var rvbahasapemrograman: RecyclerView
    private var list: ArrayList<bahasapemrograman> = arrayListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rvbahasapemrograman = findViewById(R.id.rv_bahasapemrograman)
        rvbahasapemrograman.setHasFixedSize(true)
        list.addAll(data_bahasapemrograman.list_bahasapemrograman)
        showbahasapemrogramanList()
    }

    private fun showbahasapemrogramanList(){
        rvbahasapemrograman.layoutManager = LinearLayoutManager(this)
        rvbahasapemrograman.adapter = list_bahasapemrograman(this,list){
            Toast.makeText(this,it.detail,Toast.LENGTH_SHORT).show();
        }
    }
}
